package PracticeJava.Collection;

public class Course
{
    String name;

    String id;

    int credits;

    public Course( String name, String id, int credits )
    {
        this.name = name;
        this.id = id;
        this.credits = credits;
    }
    public String getName() {
    	return name;
    }
    public String getId() {
    	return id;
    }
    public int getCredits() {
    	return credits;
    }
    @Override
    public String toString()
    {
        return "Course{" + "name='" + name + '\'' + ", id='" + id + '\'' + ", credits=" + credits + '}';
    }
}
